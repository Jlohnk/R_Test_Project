#' Prediction of Churn Probability
#'
# Description
#' This function computes the probability of churning for a single Customer
#'
#' @export


churn_prediction <- function(dataset, CustomerID){

  # Check if CustomerID exists in dataset
  if (!(CustomerID %in% dataset$CustomerId)) {
    stop("CustomerID does not exist in the dataset.")
  }

  # Estimate probability to churn
  churn_prob <- glm(Exited ~    CreditScore
                    + Gender
                    + Age
                    + Tenure
                    + Balance
                    + NumOfProducts
                    + HasCrCard
                    + IsActiveMember
                    + EstimatedSalary
                    , data = dataset
                    , family = "binomial"
  )

  # Predict churn probability for Customer
  dataset$churn_predict <- predict(churn_prob, dataset, type = "response")

  # Get result for CustomerID
  result <- dataset[CustomerId == CustomerID, churn_predict]
  return(result)
}
