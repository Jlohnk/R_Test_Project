context("max must be always greater than min")
test_that("expect max pred churn prob must be always bigger than min pred churn prob",{
  expect_true(churn_prediction(dataset, 15653251) > churn_prediction(dataset, 15662641))
})
